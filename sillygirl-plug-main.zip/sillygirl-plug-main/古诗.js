// [rule: 古诗 ]
sendText(request({url:"https://v1.jinrishici.com/rensheng.txt"}))
