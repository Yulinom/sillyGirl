//[rule: 烟雨阁 ]
//[rule: 首页 ]
sendText("烟雨阁地址：https://www.yanyuwangluo.cn" + 
		"\n新增分享目录，可以把自己写好的插件或者找到好的插件上传分享。" +
		"\n傻妞插件：http://wpan.yanyuwangluo.cn/")
