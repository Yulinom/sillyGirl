// [rule: test]
// [rule: test ?]
// [rule: 群信息]

sendText("当前群信息"+"\n发送人昵称:"+GetUsername()+"\n发送人微信号："+GetUserID()+"\n当前群号："+GetChatID())

