//烟雨阁出品 https://www.yanyuwangluo.cn/
// 生成二维码
// [rule: 生成 ? ] 生成 北京
sendImage("https://api.ixiaowai.cn/ewm/?m=4&e=L&p=6&text="+param(1))

