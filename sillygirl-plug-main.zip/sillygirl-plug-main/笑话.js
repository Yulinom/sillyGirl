// [rule: ^(.*)笑话(.*)$ ]
sendText(request({url:"https://www.hlapi.cn/api/gxdz"}))
