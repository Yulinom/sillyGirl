/*
 * @Date: 2022-03-08 15:03:47
 * @LastEditors: 烟雨
 * @LastEditTime: 2022-03-08 15:05:24
 * @FilePath: \undefinedc:\Users\Administrator\Desktop\举牌.js
 */

//[rule: 举牌 ?] 举牌 烟雨阁
sendImage("http://lkaa.top/API/pai/?msg="+encodeURI(param(1)))