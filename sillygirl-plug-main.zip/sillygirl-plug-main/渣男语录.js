// [rule: ^(.*)渣男(.*)$ ]
sendText(request({url:"https://api.iyk0.com/zhanan/"}))