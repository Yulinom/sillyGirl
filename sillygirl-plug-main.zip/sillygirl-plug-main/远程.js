//[rule: 远程 ]
//[rule: 远程下载 ]
//[rule: 远程软件 ]
sendText("只接受Todesk远程，访问下面的网址下载绿色版截图发我" +
		"\nTodesk下载：https://www.todesk.com/download.html")
